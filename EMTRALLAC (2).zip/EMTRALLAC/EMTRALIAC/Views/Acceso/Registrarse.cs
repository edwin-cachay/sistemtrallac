﻿namespace EMTRALLAC.Views.Acceso
{
    public class Registrarse
    {
    }
}
