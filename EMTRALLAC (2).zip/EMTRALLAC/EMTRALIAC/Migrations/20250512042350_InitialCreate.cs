﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace EMTRALLAC.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Ciudades",
                columns: table => new
                {
                    IdCiudad = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NombreCiudad = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Departamento = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Ciudades__D4D3CCB07F30B61C", x => x.IdCiudad);
                });

            migrationBuilder.CreateTable(
                name: "Usuarios",
                columns: table => new
                {
                    IdUsuario = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Password = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Correo = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Nombre = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Apellido = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Usuarios", x => x.IdUsuario);
                });

            migrationBuilder.CreateTable(
                name: "Viajes",
                columns: table => new
                {
                    IdViaje = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IdCiudadOrigen = table.Column<int>(type: "int", nullable: false),
                    IdCiudadDestino = table.Column<int>(type: "int", nullable: false),
                    FechaSalida = table.Column<DateTime>(type: "datetime", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Viajes__580AB6B918D975AD", x => x.IdViaje);
                    table.ForeignKey(
                        name: "FK__Viajes__IdCiudad__619B8048",
                        column: x => x.IdCiudadOrigen,
                        principalTable: "Ciudades",
                        principalColumn: "IdCiudad");
                    table.ForeignKey(
                        name: "FK__Viajes__IdCiudad__628FA481",
                        column: x => x.IdCiudadDestino,
                        principalTable: "Ciudades",
                        principalColumn: "IdCiudad");
                });

            migrationBuilder.CreateTable(
                name: "Pasajes",
                columns: table => new
                {
                    IdPasaje = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IdViaje = table.Column<int>(type: "int", nullable: false),
                    Precio = table.Column<decimal>(type: "decimal(10,2)", nullable: false),
                    Compania = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Pasajes__1DA80C5E2DF1C474", x => x.IdPasaje);
                    table.ForeignKey(
                        name: "FK__Pasajes__IdViaje__656C112C",
                        column: x => x.IdViaje,
                        principalTable: "Viajes",
                        principalColumn: "IdViaje");
                });

            migrationBuilder.InsertData(
                table: "Ciudades",
                columns: new[] { "IdCiudad", "Departamento", "NombreCiudad" },
                values: new object[,]
                {
                    { 1, "Cajamarca", "Cajamarca" },
                    { 2, "Cajamarca", "Jaen" },
                    { 3, "Cajamarca", "Chota" },
                    { 4, "Cajamarca", "Bambamarca" },
                    { 5, "Cajamarca", "Hualgayoc" },
                    { 6, "Cajamarca", "San Miguel" },
                    { 7, "Cajamarca", "San Marcos" }
                });

            migrationBuilder.InsertData(
                table: "Viajes",
                columns: new[] { "IdViaje", "FechaSalida", "IdCiudadDestino", "IdCiudadOrigen" },
                values: new object[,]
                {
                    { 1, new DateTime(2024, 12, 25, 10, 0, 0, 0, DateTimeKind.Unspecified), 2, 1 },
                    { 2, new DateTime(2024, 12, 26, 12, 0, 0, 0, DateTimeKind.Unspecified), 3, 2 },
                    { 3, new DateTime(2025, 1, 1, 14, 0, 0, 0, DateTimeKind.Unspecified), 1, 3 }
                });

            migrationBuilder.InsertData(
                table: "Pasajes",
                columns: new[] { "IdPasaje", "Compania", "IdViaje", "Precio" },
                values: new object[,]
                {
                    { 1, "Emtrallac", 1, 50.00m },
                    { 2, "Emtrallac", 2, 60.00m },
                    { 3, "Emtrallac", 3, 40.00m }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Pasajes_IdViaje",
                table: "Pasajes",
                column: "IdViaje");

            migrationBuilder.CreateIndex(
                name: "IX_Usuarios_Correo",
                table: "Usuarios",
                column: "Correo",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Viajes_IdCiudadDestino",
                table: "Viajes",
                column: "IdCiudadDestino");

            migrationBuilder.CreateIndex(
                name: "IX_Viajes_IdCiudadOrigen",
                table: "Viajes",
                column: "IdCiudadOrigen");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Pasajes");

            migrationBuilder.DropTable(
                name: "Usuarios");

            migrationBuilder.DropTable(
                name: "Viajes");

            migrationBuilder.DropTable(
                name: "Ciudades");
        }
    }
}
