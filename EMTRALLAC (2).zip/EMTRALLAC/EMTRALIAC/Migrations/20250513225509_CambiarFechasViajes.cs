﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EMTRALLAC.Migrations
{
    /// <inheritdoc />
    public partial class CambiarFechasViajes : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Viajes",
                keyColumn: "IdViaje",
                keyValue: 1,
                column: "FechaSalida",
                value: new DateTime(2025, 5, 18, 10, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                table: "Viajes",
                keyColumn: "IdViaje",
                keyValue: 2,
                column: "FechaSalida",
                value: new DateTime(2025, 5, 19, 12, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                table: "Viajes",
                keyColumn: "IdViaje",
                keyValue: 3,
                column: "FechaSalida",
                value: new DateTime(2025, 5, 19, 14, 0, 0, 0, DateTimeKind.Unspecified));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Viajes",
                keyColumn: "IdViaje",
                keyValue: 1,
                column: "FechaSalida",
                value: new DateTime(2024, 12, 25, 10, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                table: "Viajes",
                keyColumn: "IdViaje",
                keyValue: 2,
                column: "FechaSalida",
                value: new DateTime(2024, 12, 26, 12, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                table: "Viajes",
                keyColumn: "IdViaje",
                keyValue: 3,
                column: "FechaSalida",
                value: new DateTime(2025, 1, 1, 14, 0, 0, 0, DateTimeKind.Unspecified));
        }
    }
}
