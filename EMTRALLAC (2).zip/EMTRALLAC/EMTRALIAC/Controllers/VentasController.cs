﻿
using Microsoft.AspNetCore.Mvc;
using EMTRALLAC.Data;
using EMTRALLAC.ViewModels;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;

namespace EMTRALLAC.Controllers
{
    public class VentasController : Controller
    {
        private readonly AppDbContext _context;

        public VentasController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var model = new SearchViewModel
            {
                Cities = _context.Ciudades.ToList()
            };
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> BuscarViajes(string CiudadOrigen, string CiudadDestino, DateTime? FechaIda, DateTime? FechaRetorno)
        {
            if (!FechaIda.HasValue)
            {
                ViewBag.ErrorMessage = "La fecha de ida es requerida.";
                return View("Index");
            }

            var resultados = await _context.Viajes
                .Include(v => v.IdCiudadOrigenNavigation)
                .Include(v => v.IdCiudadDestinoNavigation)
                .Include(v => v.Pasajes)
                .Where(v => v.IdCiudadOrigenNavigation.NombreCiudad.ToLower() == CiudadOrigen.ToLower() &&
                            v.IdCiudadDestinoNavigation.NombreCiudad.ToLower() == CiudadDestino.ToLower() &&
                            v.FechaSalida.Date == FechaIda.Value.Date)
                .SelectMany(v => v.Pasajes, (v, p) => new PasajeResultado
                {
                    Compania = "EMTRALLAC",
                    HoraSalida = v.FechaSalida,
                    Precio = p.Precio
                })
                .ToListAsync();

            var viewModel = new SearchResultsViewModel
            {
                CiudadOrigen = CiudadOrigen,
                CiudadDestino = CiudadDestino,
                FechaIda = FechaIda.Value,
                FechaRetorno = FechaRetorno,
                Resultados = resultados
            };

            return View("ResultadosBusqueda", viewModel);
        }
    }
}
