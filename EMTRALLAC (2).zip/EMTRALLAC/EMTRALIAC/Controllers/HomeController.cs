using Microsoft.AspNetCore.Mvc;
using EMTRALLAC.Data; // Aseg�rate de tener esta using
using EMTRALLAC.ViewModels; // Aseg�rate de tener esta using
using System.Linq;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using EMTRALLAC.Models;
using System.Diagnostics;

namespace EMTRALLAC.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _context;
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger, AppDbContext context) // Aseg�rate de recibir AppDbContext
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult INICIO()
        {
            return View();
        }

        public IActionResult INTERPROVINCIAL()
        {
            return View();
        }
        public IActionResult ENCOMIENDAS()
        {
            return View();
        }
        public IActionResult TRANSPORTEPERSONAL()
        {
            return View();
        }

        public IActionResult LOGIN()
        {
            return View();
        }

        public IActionResult ADMINISTRADOR()
        {
            return View();
        }

        public async Task<IActionResult> VENTAPASAJES()
        {
            var viewModel = new SearchViewModel
            {
                Cities = await _context.Ciudades.ToListAsync()
            };
            return View(viewModel);
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
