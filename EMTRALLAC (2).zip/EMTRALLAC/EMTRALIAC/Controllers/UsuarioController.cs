﻿using AspNetCoreGeneratedDocument;
using EMTRALLAC.Data;
using EMTRALLAC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EMTRALLAC.Controllers
{
    public class UsuarioController : Controller
    {
        private readonly AppDbContext _appDBContext; // solo lectura
        public UsuarioController(AppDbContext appDBContext)
        {
            _appDBContext = appDBContext;
        }
        [HttpGet]
        public async Task<IActionResult> Lista()
        {
            List<Usuario> lista = await _appDBContext.Usuarios.ToListAsync();
            return View(lista);
        }
        [HttpGet]
        public async Task<IActionResult> Nuevo()
        {
            return View();
        }

        [HttpPost]

        public async Task<IActionResult> Nuevo(Usuario Usuario)
        {
            await _appDBContext.Usuarios.AddAsync(Usuario);
            await _appDBContext.SaveChangesAsync();
            return RedirectToAction(nameof(Lista));
        }
        [HttpGet]
        public async Task<IActionResult> Editar(int id)
        {
            Usuario Usuario = await _appDBContext.Usuarios.FirstAsync(u => u.IdUsuario == id);
            return View(Usuario);
        }
        [HttpPost]
        public async Task<IActionResult> Editar(Usuario usuario)
        {
            _appDBContext.Usuarios.Update(usuario);
            await _appDBContext.SaveChangesAsync();
            return RedirectToAction(nameof(Lista));
        }
        [HttpGet]
        public async Task<IActionResult> Eliminar(int id)
        {
            Usuario usuario = await _appDBContext.Usuarios.FirstAsync(u => u.IdUsuario == id);
            _appDBContext.Usuarios.Remove(usuario);
            await _appDBContext.SaveChangesAsync();
            return RedirectToAction(nameof(Lista));
        }
    }
}
