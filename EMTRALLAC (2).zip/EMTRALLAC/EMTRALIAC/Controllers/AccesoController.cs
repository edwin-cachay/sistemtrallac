﻿

using Microsoft.AspNetCore.Mvc;
using EMTRALLAC.Models;
using EMTRALLAC.Data;
using Microsoft.EntityFrameworkCore;
using EMTRALLAC.ViewModels;
using System;
using System.Threading.Tasks; // Asegúrate de tener esto

namespace EMTRALLAC.Controllers
{
    public class AccesoController : Controller
    {
        private readonly AppDbContext _appDBContext;
        public AccesoController(AppDbContext appDBContext)
        {
            _appDBContext = appDBContext;
        }
        [HttpGet]
        public IActionResult Registrarse()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Registrarse(UsuarioVM model)
        {
            if (model.Password != model.RepPassword)
            {
                ViewData["Mensaje"] = "Las contraseñas no coinciden";
                return View();
            }

            // **AQUÍ ESTÁ LA VERIFICACIÓN DEL CORREO ELECTRÓNICO**
            var usuarioExistente = await _appDBContext.Usuarios.FirstOrDefaultAsync(u => u.Correo == model.Correo);

            if (usuarioExistente != null)
            {
                ViewData["Mensaje"] = "Este correo electrónico ya está registrado.";
                return View();
            }

            // Si no existe, entonces procede a crear el nuevo usuario y guardar...
            Usuario usuario = new Usuario()
            {
                Nombre = model.Nombre,
                Apellido = model.Apellido,
                Correo = model.Correo,
                Password = model.Password
            };
            await _appDBContext.Usuarios.AddAsync(usuario);
            await _appDBContext.SaveChangesAsync();
            if (usuario.IdUsuario != 0) return RedirectToAction("LOGIN", "Home");
            ViewData["Mensaje"] = "El usuario no pudo crearse";
            return View();
        }
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Login(LoginVM model)
        {
            Usuario? usuario_encontrado = await _appDBContext.Usuarios.Where(u => u.Correo == model.Correo && u.Password == model.Password).FirstOrDefaultAsync();
            if (usuario_encontrado == null)
            {
                ViewData["mensaje"] = "El usuario no existe";
                return View();
            }
            return RedirectToAction("INICIO", "Home");


        }







    }
}
