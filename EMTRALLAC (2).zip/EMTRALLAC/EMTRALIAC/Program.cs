

using EMTRALLAC.Data;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Agregar servicios al contenedor
builder.Services.AddControllersWithViews();

// Configurar AppDbContext con la cadena de conexi�n definida en appsettings.json
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("CadenaSQL"))
);

var app = builder.Build();

// Configuraci�n del pipeline HTTP
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts(); // Recomendado en producci�n para seguridad
}

// Agregar redirecci�n HTTPS (mejora la seguridad)
app.UseHttpsRedirection();

// Archivos est�ticos (para im�genes, CSS, JS, etc.)
app.UseStaticFiles();

// Configuraci�n de enrutamiento
app.UseRouting();

// Autorizaci�n de usuario
app.UseAuthorization();

// Rutas predeterminadas de los controladores
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=LOGIN}/{id?}"
);

app.Run();
