﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EMTRALLAC.Models;

public partial class Ciudad
{
    [Key]
    public int IdCiudad { get; set; }

    [Required]
    [StringLength(100)]
    public string NombreCiudad { get; set; } = null!;

    [StringLength(100)]
    public string? Departamento { get; set; }

    public virtual ICollection<Viaje> ViajeIdCiudadDestinoNavigations { get; set; } = new List<Viaje>();

    public virtual ICollection<Viaje> ViajeIdCiudadOrigenNavigations { get; set; } = new List<Viaje>();
}