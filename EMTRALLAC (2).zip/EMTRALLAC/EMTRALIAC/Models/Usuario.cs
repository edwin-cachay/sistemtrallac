﻿



using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace EMTRALLAC.Models;

[Index(nameof(Correo), IsUnique = true, Name = "IX_Usuarios_Correo")]
public partial class Usuario
{
    [Key]
    public int IdUsuario { get; set; }

    [Required]
    [StringLength(50)]
    public string Password { get; set; } = null!;

    [Required]
    [StringLength(50)]
    public string Correo { get; set; } = null!;

    [Required]
    [StringLength(50)]
    public string Nombre { get; set; } = null!;

    [Required]
    [StringLength(50)]
    public string Apellido { get; set; } = null!;

    // Campos agregados del primer código
    public DateOnly FechaContrato { get; set; }
    public bool Estado { get; set; }
}
