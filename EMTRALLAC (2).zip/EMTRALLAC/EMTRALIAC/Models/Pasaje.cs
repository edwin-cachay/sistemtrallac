﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EMTRALLAC.Models;

public partial class Pasaje
{
    [Key]
    public int IdPasaje { get; set; }

    [Required]
    [ForeignKey("Viaje")]
    public int IdViaje { get; set; }

    [Column(TypeName = "decimal(10, 2)")]
    [Required] // Add this to ensure Precio is required
    public decimal Precio { get; set; }

    [MaxLength(100)]
    public string? Compania { get; set; }

    public virtual Viaje IdViajeNavigation { get; set; } = null!;
}