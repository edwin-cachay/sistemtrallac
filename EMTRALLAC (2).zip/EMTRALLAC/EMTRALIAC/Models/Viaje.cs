﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EMTRALLAC.Models;

public partial class Viaje
{
    [Key]
    public int IdViaje { get; set; }

    [Required]
    [ForeignKey("CiudadOrigen")]
    public int IdCiudadOrigen { get; set; }

    [Required]
    [ForeignKey("CiudadDestino")]
    public int IdCiudadDestino { get; set; }

    [Required]
    public DateTime FechaSalida { get; set; }

    public virtual Ciudad IdCiudadDestinoNavigation { get; set; } = null!;

    public virtual Ciudad IdCiudadOrigenNavigation { get; set; } = null!;

    public virtual ICollection<Pasaje> Pasajes { get; set; } = new List<Pasaje>();
}