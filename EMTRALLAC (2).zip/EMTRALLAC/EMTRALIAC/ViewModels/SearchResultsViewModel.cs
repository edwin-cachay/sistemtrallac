﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EMTRALLAC.ViewModels
{
    public class SearchResultsViewModel
    {
        [Required(ErrorMessage = "La ciudad de origen es requerida")] // Añadido
        public string CiudadOrigen { get; set; }
        [Required(ErrorMessage = "La ciudad de destino es requerida")] // Añadido
        public string CiudadDestino { get; set; }
        [Required(ErrorMessage = "La fecha de ida es requerida")]  // Añadido
        public DateTime FechaIda { get; set; }
        public DateTime? FechaRetorno { get; set; }
        public List<PasajeResultado> Resultados { get; set; } = new List<PasajeResultado>(); // Inicialización

    }

    public class PasajeResultado
    {
        public string Compania { get; set; }
        public DateTime HoraSalida { get; set; }
        public decimal Precio { get; set; }
        // Puedes agregar más propiedades relevantes del pasaje
    }
}
