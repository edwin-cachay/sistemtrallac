﻿namespace EMTRALLAC.ViewModels
{
    public class CiudadesVM
    {
        public string NombreCiudad { get; set; }
        // Podrías agregar otras propiedades que necesites en la vista,
        // como IdCiudad si necesitas el ID para alguna operación.
    }
}
