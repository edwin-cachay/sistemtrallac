﻿using EMTRALLAC.Models;
using System.ComponentModel.DataAnnotations;
using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering; // Import para SelectList

namespace EMTRALLAC.ViewModels
{
    public class SearchViewModel
    {
        public List<Ciudad> Cities { get; set; }

        [Required(ErrorMessage = "Por favor, seleccione una ciudad de origen.")]
        public string CiudadOrigen { get; set; }

        [Required(ErrorMessage = "Por favor, seleccione una ciudad de destino.")]
        public string CiudadDestino { get; set; }

        [Required(ErrorMessage = "Por favor, seleccione una fecha de ida.")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public string FechaIda { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public string FechaRetorno { get; set; } // Opcional

        public SelectList CiudadOrigenSelectList { get; set; }  // Para el DropDownList de Origen
        public SelectList CiudadDestinoSelectList { get; set; }  // Para el DropDownList de Destino
    }
}
