﻿namespace EMTRALLAC.ViewModels
{
    public class LoginVM
    {
        public string Correo { get; set; }
        public string Password { get; set; }
    }
}
