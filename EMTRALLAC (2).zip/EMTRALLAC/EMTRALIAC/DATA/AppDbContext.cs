﻿using System;
using System.Collections.Generic;
using EMTRALLAC.Data;
using EMTRALLAC.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Configuration;

namespace EMTRALLAC.Data;

public partial class AppDbContext : DbContext
{
    public AppDbContext()
    {
    }

    public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Ciudad> Ciudades { get; set; }

    public virtual DbSet<Pasaje> Pasajes { get; set; }

    public virtual DbSet<Usuario> Usuarios { get; set; }

    public virtual DbSet<Viaje> Viajes { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!optionsBuilder.IsConfigured)
        {
            IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();
            var connectionString = configuration.GetConnectionString("CadenaSQL");
            optionsBuilder.UseSqlServer(connectionString);
        }
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Ciudad>(entity =>
        {
            entity.HasKey(e => e.IdCiudad).HasName("PK__Ciudades__D4D3CCB07F30B61C");
            entity.Property(e => e.Departamento).HasMaxLength(100);
            entity.Property(e => e.NombreCiudad).HasMaxLength(100);
        });

        modelBuilder.Entity<Pasaje>(entity =>
        {
            entity.HasKey(e => e.IdPasaje).HasName("PK__Pasajes__1DA80C5E2DF1C474");
            entity.Property(e => e.Compania).HasMaxLength(100);
            entity.Property(e => e.Precio).HasColumnType("decimal(10, 2)");
            entity.HasOne(d => d.IdViajeNavigation).WithMany(p => p.Pasajes)
                .HasForeignKey(d => d.IdViaje)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Pasajes__IdViaje__656C112C");
        });

        modelBuilder.Entity<Usuario>(entity =>
        {
            entity.HasKey(e => e.IdUsuario);
            entity.HasIndex(e => e.Correo, "IX_Usuarios_Correo").IsUnique();
            entity.Property(e => e.Apellido).HasMaxLength(50);
            entity.Property(e => e.Correo).HasMaxLength(50);
            entity.Property(e => e.Nombre).HasMaxLength(50);
            entity.Property(e => e.Password).HasMaxLength(50);
            // Configuración de los nuevos campos
            entity.Property(e => e.FechaContrato).HasColumnType("date"); // Especifica el tipo de dato
            entity.Property(e => e.Estado).HasColumnType("bit");       // Especifica el tipo de dato
        });

        modelBuilder.Entity<Viaje>(entity =>
        {
            entity.HasKey(e => e.IdViaje).HasName("PK__Viajes__580AB6B918D975AD");
            entity.Property(e => e.FechaSalida).HasColumnType("datetime");
            entity.HasOne(d => d.IdCiudadDestinoNavigation).WithMany(p => p.ViajeIdCiudadDestinoNavigations)
                .HasForeignKey(d => d.IdCiudadDestino)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Viajes__IdCiudad__628FA481");
            entity.HasOne(d => d.IdCiudadOrigenNavigation).WithMany(p => p.ViajeIdCiudadOrigenNavigations)
                .HasForeignKey(d => d.IdCiudadOrigen)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Viajes__IdCiudad__619B8048");
        });

        // Seed data for Ciudades
        modelBuilder.Entity<Ciudad>().HasData(
            new Ciudad { IdCiudad = 1, NombreCiudad = "Cajamarca", Departamento = "Cajamarca" },
            new Ciudad { IdCiudad = 2, NombreCiudad = "Jaen", Departamento = "Cajamarca" },
            new Ciudad { IdCiudad = 3, NombreCiudad = "Chota", Departamento = "Cajamarca" },
            new Ciudad { IdCiudad = 4, NombreCiudad = "Bambamarca", Departamento = "Cajamarca" },
            new Ciudad { IdCiudad = 5, NombreCiudad = "Hualgayoc", Departamento = "Cajamarca" },
            new Ciudad { IdCiudad = 6, NombreCiudad = "San Miguel", Departamento = "Cajamarca" },
            new Ciudad { IdCiudad = 7, NombreCiudad = "San Marcos", Departamento = "Cajamarca" }
           
        );

        // Seed data for Viajes
        modelBuilder.Entity<Viaje>().HasData(
            new Viaje { IdViaje = 1, IdCiudadOrigen = 1, IdCiudadDestino = 2, FechaSalida = new DateTime(2025, 05, 18, 10, 0, 0) }, // Fecha estática
            new Viaje { IdViaje = 2, IdCiudadOrigen = 2, IdCiudadDestino = 3, FechaSalida = new DateTime(2025, 05, 19, 12, 0, 0) }, // Fecha estática
            new Viaje { IdViaje = 3, IdCiudadOrigen = 3, IdCiudadDestino = 1, FechaSalida = new DateTime(2025, 05, 19, 14, 0, 0) }  // Fecha estática
        );

        // Seed data for Pasajes
        modelBuilder.Entity<Pasaje>().HasData(
            new Pasaje { IdPasaje = 1, IdViaje = 1, Compania = "Emtrallac", Precio = 50.00M },
            new Pasaje { IdPasaje = 2, IdViaje = 2, Compania = "Emtrallac", Precio = 60.00M },
            new Pasaje { IdPasaje = 3, IdViaje = 3, Compania = "Emtrallac", Precio = 40.00M }
        );

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
